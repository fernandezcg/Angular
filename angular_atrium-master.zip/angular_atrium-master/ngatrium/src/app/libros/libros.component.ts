import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'iam-libros',
  templateUrl: './libros.component.html',
  styleUrls: ['./libros.component.css']
})
export class LibrosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
