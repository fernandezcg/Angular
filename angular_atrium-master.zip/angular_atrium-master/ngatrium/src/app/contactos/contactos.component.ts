import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'iam-contactos',
  templateUrl: './contactos.component.html',
  styleUrls: ['./contactos.component.css']
})
export class ContactosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
