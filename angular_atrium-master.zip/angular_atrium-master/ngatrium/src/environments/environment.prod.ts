export const environment = {
  production: true,
  apiLibros: 'https://www.miempresa.com/books?q=intitle:'
};
