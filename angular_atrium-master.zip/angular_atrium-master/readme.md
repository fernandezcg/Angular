# Ejercios de Angular del curso de Atrium #

## Entorno Front ##

- VSC
- (git -> github)
- node / npm
- http-server -> npm install -g http-server

## Entorno y proyecto de Angular ##

- Angular CLI -> npm install -g @angular/cli
- nuevo proyecto
ng new -p iam --routing <nombre>
- accedemos al proyecto cd <nombre>
- arrancamos "angular" -> ng serve -> webpack

## Elementos adicionales ##

- Boostrap
- ng Bootstrap