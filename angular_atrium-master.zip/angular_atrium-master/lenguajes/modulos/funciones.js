import { algo } from './independiente.js'

export function saludar(name="un amigo") {
    algo()
    console.log(`Hola soy ${name}`)
}
