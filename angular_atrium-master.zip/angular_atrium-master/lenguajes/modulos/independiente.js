export function algo() {
    console.log('Soy algo')
}
