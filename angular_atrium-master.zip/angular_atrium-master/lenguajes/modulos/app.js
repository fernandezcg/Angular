import { saludar } from './funciones.js'

saludar()
saludar('Pepe')