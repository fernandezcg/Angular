function algo1 () {
    // TODO: añadir el código
}

let oDatos = {}

let algo2 = function () {}

let arrowAlgo = () => {}

function sumar (a,b) {
    return a+b
}

// let sumar = (a,b) => {return a+b}

let sumarAlgo = (a,b) => a+b

console.log(sumarAlgo(12,12))
