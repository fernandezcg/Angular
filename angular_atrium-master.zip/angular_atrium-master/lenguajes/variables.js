let x = 23

function algo () {
    if (true) {
        let y = 27
        console.log(y)
    }
    console.log(x)
}

algo()

const z = 56
// z++

const aDatos = [1,2,3,4,5]
aDatos.push(6)

// aDatos = []
console.log(aDatos)
